export * from '../build/Main/tact_Main';
