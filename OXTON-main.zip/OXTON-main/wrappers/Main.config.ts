export const mainConfig = {
    baseAddress: 'EQBsdQdZHI4hb4rgIkwoYTbyUsp6p5tei4ODSOY9WIPvYcM4'
}